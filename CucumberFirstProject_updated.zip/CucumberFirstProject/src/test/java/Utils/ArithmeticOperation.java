package Utils;

public class ArithmeticOperation {



    private Integer x;

    public Integer getX() {
        return x;
    }

    public void setX(Integer x) {
        this.x = x;
    }

    public Integer getY() {
        return y;
    }

    public void setY(Integer y) {
        this.y = y;
    }

    private Integer y;



    public int add()
    {
        return x+y;
    }

    public int subtract()
    {
        if(x>y){
        return x-y;}

        else{
            return y-x;
        }

    }

    public int multiply()
    {
        return x*y;
    }


    public int divide()
    {
        int quotient=0;
        if(y>0) {
            quotient= x / y;
        }

        return quotient;
    }




}
