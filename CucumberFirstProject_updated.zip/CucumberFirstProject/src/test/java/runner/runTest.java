package runner;

import cucumber.api.CucumberOptions;
import cucumber.api.junit.Cucumber;
import org.junit.runner.RunWith;

@RunWith(Cucumber.class)
@CucumberOptions(
        glue = {"stepDefs"},
        features = "./src/test/resources/feature",
        format = {"pretty", "html:target/Destination"},
        tags={"~@add","~@subtract","@multiply,@divide,@Friday"})

//Specifying pretty as a format option ensure that HTML report will be generated.
//

public class runTest { }