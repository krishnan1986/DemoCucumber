package stepDefs;

import cucumber.api.DataTable;
import cucumber.api.PendingException;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import org.junit.Assert;
import Utils.ArithmeticOperation;
import Utils.CheckInput;

import java.util.List;

public class StepDef {

    ArithmeticOperation arithmeticOperation = new ArithmeticOperation();

     CheckInput checkInput = new CheckInput();

    @Given("^I have two numbers x and y$")
    public void i_have_two_numbers_and(DataTable inputs) throws Throwable {


             List<List<String>> data = inputs.raw();
             arithmeticOperation.setX(Integer.parseInt(data.get(1).get(0)));
             arithmeticOperation.setY(Integer.parseInt(data.get(1).get(1)));

    }

    @Then("^sum of two numbers is x\\+y$")
    public void sum_of_two_numbers_is_x_y() throws Throwable {

        Assert.assertEquals(arithmeticOperation.add(),3);

    }

    @Then("^difference of two numbers is x-y$")
    public void difference_of_two_numbers_is_x_y() throws Throwable {

        Assert.assertEquals(arithmeticOperation.subtract(),1);
    }

    @Then("^product of these two is x \\*y$")
    public void product_of_these_two_is_x_y() throws Throwable {
        Assert.assertEquals(arithmeticOperation.multiply(),2);
    }


    @Then("^quotient of these two is x /y$")
    public void quotient_of_these_two_is_x_y() throws Throwable {

        Assert.assertEquals(arithmeticOperation.divide(),0);
    }
}
